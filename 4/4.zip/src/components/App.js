import React from 'react';
import TodoTable from './TodoTable';


export default class App extends React.Component {
    render() {
        return (
            <TodoTable/>
        )
    }
}